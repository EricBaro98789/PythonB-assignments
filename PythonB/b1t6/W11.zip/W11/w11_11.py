# Sending a welcome message to different users

user1 = "Alice"
message1 = f"Hello, {user1}! Welcome to our platform."
print(message1)

user2 = "Bob"
message2 = f"Hello, {user2}! Welcome to our platform."
print(message2)

user3 = "Charlie"
message3 = f"Hello, {user3}! Welcome to our platform."
print(message3)
