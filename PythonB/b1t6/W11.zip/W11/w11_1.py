import math

# Original code with unclear names
p = math.pi
r = 5
h = 1

def f(a, b):
    c = 2 * p * a * (a + b)
    return c

res = f(r, h)
print(res)
