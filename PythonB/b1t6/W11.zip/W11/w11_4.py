import random

# Given some numbers
num_1 = random.randint(6,10)
num_2 = random.randint(1,5)
num_3 = random.randint(11,20)

print ('1 =>', num_1, ', 2 =>', num_2, ', 3 =>;', num_3)

if num_1 > num_2:
  if num_3 > num_1:
    bat = True
    print("both conditions are ", bat == True)
    